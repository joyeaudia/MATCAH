// cekout.js — dynamic checkout: load cart -> product summary, qty sync, place scheduled order
import { db, auth } from "./firebase-config.js";
window._auth_for_debug = auth;
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js";
import {
  collection,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";

document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  // ---- helpers ----
  const formatRp = (n) => {
    const num = Math.round(Number(n) || 0);
    const s = Math.abs(num).toString();
    const parts = [];
    for (let i = s.length - 1, cnt = 0; i >= 0; i--, cnt++) {
      parts.push(s[i]);
      if (cnt % 3 === 2 && i !== 0) parts.push('.');
    }
    const sign = num < 0 ? '-' : '';
    return sign + 'Rp ' + parts.reverse().join('') + ',00';
  };

  // Safe localStorage JSON helpers
  function safeParse(key) {
    try { return JSON.parse(localStorage.getItem(key) || '[]'); }
    catch (e) { return []; }
  }
  function saveJSON(key, v) { localStorage.setItem(key, JSON.stringify(v || [])); }
  function loadCart() { return safeParse('cart'); }
  function saveCart(cart) { saveJSON('cart', cart); }
  function loadOrders() { return safeParse('orders'); }
  function saveOrders(arr) { saveJSON('orders', arr); }
  function genOrderId() {
    return 'ORD-' + new Date().toISOString().slice(0, 10) + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
  }

  // -----------------------------
  // Local queue helpers (order sync fallback)
  // -----------------------------
  function getUserKeyOrders() {
    const uid = localStorage.getItem('maziUID') || null;
    const email = (localStorage.getItem('maziEmail') || '').trim().toLowerCase();
    if (uid) return 'orders_' + uid;
    if (email) return 'orders_' + email.replace(/[@.]/g,'_');
    return 'orders_anon';
  }

  function enqueueLocalOrder(order) {
    try {
      const qKey = 'order_sync_queue';
      const raw = localStorage.getItem(qKey) || '[]';
      const arr = JSON.parse(raw);
      arr.push(order);
      localStorage.setItem(qKey, JSON.stringify(arr));
      console.log('Order queued locally for sync (queue length):', arr.length);
    } catch (e) {
      console.error('enqueueLocalOrder failed', e);
    }
  }

  async function flushOrderQueue() {
    try {
      const qKey = 'order_sync_queue';
      const raw = localStorage.getItem(qKey) || '[]';
      const arr = JSON.parse(raw);
      if (!Array.isArray(arr) || arr.length === 0) return;

      const user = auth.currentUser;
      if (!user) {
        console.warn('flushOrderQueue: no authenticated user — skip flush until login.');
        return;
      }

      console.log('Flushing order sync queue, items:', arr.length);

      for (let i = 0; i < arr.length; i++) {
        const o = arr[i];
        try {
          const firestoreOrder = {
            userId: user.uid,
            userEmail: user.email || (localStorage.getItem('maziEmail') || ''),
            userName: localStorage.getItem('maziName') || '',
            ...o,
            createdAt: serverTimestamp()
          };

          const docRef = await addDoc(collection(db, "orders"), firestoreOrder);
          console.log('Flushed order -> firestore id:', docRef.id, 'local order id:', o.id);

          // remove this item from queue
          arr.splice(i, 1);
          i--;
        } catch (err) {
          console.warn('flushOrderQueue: failed to push one order, will retry later', err);
          break;
        }
      }

      localStorage.setItem(qKey, JSON.stringify(arr));
    } catch (e) {
      console.error('flushOrderQueue failed', e);
    }
  }

  // expose flushOrderQueue to window so sign-in page can call it if needed
  window.flushOrderQueue = flushOrderQueue;

  // ---- safe html escape ----
  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // --- populate Schedule selects (Date / Month / Year) ---
  function populateScheduleSelectors({ yearsAhead = 5 } = {}) {
    const dateSel = document.querySelector('select[aria-label="Date"]');
    const monthSel = document.querySelector('select[aria-label="Month"]');
    const yearSel = document.querySelector('select[aria-label="Year"]');
    if (!dateSel || !monthSel || !yearSel) return;

    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

    // clear
    dateSel.innerHTML = '';
    monthSel.innerHTML = '';
    yearSel.innerHTML = '';

    function opt(val, text) {
      const o = document.createElement('option');
      o.value = String(val);
      o.textContent = String(text);
      return o;
    }

    // months
    monthSel.appendChild(opt('', 'Month'));
    months.forEach((m, i) => monthSel.appendChild(opt(i + 1, m)));

    // years
    const now = new Date();
    const curYear = now.getFullYear();
    yearSel.appendChild(opt('', 'Year'));
    for (let y = curYear; y <= curYear + (Number(yearsAhead) || 5); y++) {
      yearSel.appendChild(opt(y, y));
    }

    function daysInMonth(y, mIndex) {
      return new Date(y, mIndex + 1, 0).getDate();
    }

    function refillDates() {
      const selMonth = Number(monthSel.value) || (now.getMonth() + 1);
      const selYear = Number(yearSel.value) || curYear;
      const mIndex = selMonth - 1;
      const days = daysInMonth(selYear, mIndex);
      const prevValue = Number(dateSel.value) || now.getDate();

      dateSel.innerHTML = '';
      dateSel.appendChild(opt('', 'Date'));
      for (let d = 1; d <= days; d++) dateSel.appendChild(opt(d, d));

      if (prevValue >= 1 && prevValue <= days) {
        dateSel.value = String(prevValue);
      } else if (selYear === curYear && selMonth === (now.getMonth() + 1)) {
        dateSel.value = String(now.getDate());
      } else {
        dateSel.value = '1';
      }
    }

    monthSel.value = String(now.getMonth() + 1);
    yearSel.value = String(curYear);
    refillDates();

    monthSel.addEventListener('change', refillDates);
    yearSel.addEventListener('change', refillDates);
  }

  // ---- DOM refs ----
  const productList = document.querySelector('.product-list');
  const subtotalEl = document.getElementById('subtotalRp');
  const shippingEl = document.getElementById('shippingFee');
  const totalEl = document.getElementById('totalRp');
  const deliveryBtns = Array.from(document.querySelectorAll('.delivery-item'));
  const deliveryRow = document.getElementById('deliveryRow');

  const useSavedBtn = document.getElementById('btnUseSavedAddress');
  if (useSavedBtn) {
    useSavedBtn.addEventListener('click', function () {
      window.location.href = 'drafamt.html?from=checkout';
    });
  }

  const recipientInput = document.getElementById('recipient');
  try {
    const draft = localStorage.getItem('checkoutRecipientDraft_v1');
    if (recipientInput && draft) {
      recipientInput.value = draft;
      localStorage.removeItem('checkoutRecipientDraft_v1');
    }
  } catch (e) {}

  if (!productList || !subtotalEl || !shippingEl || !totalEl) {
    console.warn('cekout: required elements not found');
    return;
  }

  // ---- render product summary from cart ----
  function renderProductsFromCart() {
    const cart = loadCart();
    productList.innerHTML = '';

    if (!cart || !cart.length) {
      const li = document.createElement('li');
      li.className = 'product-item';
      li.innerHTML = `<div class="product-info"><div class="product-title">Keranjang kosong</div><div class="product-meta muted">Tambahkan produk dari keranjang</div></div>`;
      productList.appendChild(li);
      calcSubtotal();
      return;
    }

    cart.forEach((it, index) => {
      const unit = Number(it.unitPrice || it.price || 0);
      const qty = Math.max(0, Number(it.qty || 1));

      const li = document.createElement('li');
      li.className = 'product-item';
      li.dataset.cartIdx = index;

      const source = it.source ? `${it.source} • ` : '';
      const metaPrice = formatRp(unit);

      li.innerHTML = `
        <div class="product-info">
          <div class="product-title">${escapeHtml(it.title || 'Untitled')}</div>
          <div class="product-meta">${escapeHtml(source)}${metaPrice}</div>
        </div>
        <div class="qty-control" data-price="${unit}">
          <button class="qty-btn dec" aria-label="Decrease">−</button>
          <input class="qty-input" type="text" inputmode="numeric" value="${qty}" aria-label="Quantity">
          <button class="qty-btn inc" aria-label="Increase">+</button>
        </div>
      `;
      productList.appendChild(li);

      const dec = li.querySelector('.dec');
      const inc = li.querySelector('.inc');
      const input = li.querySelector('.qty-input');

      dec.addEventListener('click', () => {
        let v = Number(input.value) || 0;
        v = Math.max(0, v - 1);
        input.value = String(v);
        updateCartQtyFromUI(index, v);
      });

      inc.addEventListener('click', () => {
        let v = Number(input.value) || 0;
        v = v + 1;
        input.value = String(v);
        updateCartQtyFromUI(index, v);
      });

      input.addEventListener('input', () => {
        input.value = input.value.replace(/[^\d]/g, '');
        if (input.value === '') input.value = '0';
        const v = Number(input.value);
        updateCartQtyFromUI(index, v);
      });
    });
  }

  function updateCartQtyFromUI(idx, qty) {
    const cart = loadCart();
    if (!cart || !cart[idx]) {
      calcSubtotal();
      return;
    }

    cart[idx].qty = Number(qty || 0);
    cart[idx].subtotal = Number(Number(cart[idx].unitPrice || cart[idx].price || 0) * Number(cart[idx].qty || 0));

    if (cart[idx].qty <= 0) {
      cart.splice(idx, 1);
    }

    saveCart(cart);
    renderProductsFromCart();
    calcSubtotal();
  }

  deliveryBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      deliveryBtns.forEach(b => { b.classList.remove('active'); b.setAttribute('aria-pressed', 'false'); });
      btn.classList.add('active');
      btn.setAttribute('aria-pressed', 'true');
      if (typeof btn.scrollIntoView === 'function') btn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      calcSubtotal();
    });
  });

  function calcSubtotal() {
    const cart = loadCart();
    let totalItems = 0;
    let totalPrice = 0;

    if (Array.isArray(cart)) {
      cart.forEach(it => {
        const price = Number(it.unitPrice || it.price || 0);
        const qty = Math.max(0, Number(it.qty || 0));
        totalPrice += price * qty;
        totalItems += qty;
      });
    }

    const activeMethod = document.querySelector('.delivery-item.active')?.dataset.method || 'regular';
    let baseOngkir = 15000;
    switch (activeMethod) {
      case 'regular': baseOngkir = 15000; break;
      case 'nextday': baseOngkir = 20000; break;
      case 'sameday': baseOngkir = 30000; break;
      case 'instant': baseOngkir = 50000; break;
      case 'self': baseOngkir = 5000; break;
      default: baseOngkir = 15000; break;
    }

    const kelipatan = totalItems > 0 ? Math.max(1, Math.ceil(totalItems / 5)) : 1;
    const shippingFee = baseOngkir * kelipatan;
    const grandTotal = totalPrice + shippingFee;

    if (subtotalEl) subtotalEl.textContent = formatRp(totalPrice);
    if (shippingEl) shippingEl.textContent = formatRp(shippingFee);
    if (totalEl) totalEl.textContent = formatRp(grandTotal);
  }

  // ---- Place Order: create scheduled order and redirect ----
  const placeOrderBtn = document.getElementById('placeOrder');
  if (placeOrderBtn) {
    placeOrderBtn.addEventListener('click', async function () {
      const cart = loadCart();
      if (!cart || !cart.length) {
        alert('Keranjang kosong — tidak ada yang dipesan.');
        return;
      }

      // pastikan user login sebelum buat order
      if (!auth.currentUser) {
        try { localStorage.setItem('checkoutDraft_cart', JSON.stringify(cart)); } catch(e){}
        alert('Silakan sign in dulu untuk melanjutkan pemesanan.');
        window.location.href = 'singin.html?from=checkout';
        return;
      }

      // read schedule selects -> build ISO date if valid
      let scheduledAt = null;
      try {
        const dateSel = document.querySelector('select[aria-label="Date"]');
        const monthSel = document.querySelector('select[aria-label="Month"]');
        const yearSel = document.querySelector('select[aria-label="Year"]');
        const dateVal = dateSel?.value || '';
        const monthVal = monthSel?.value || '';
        const yearVal = yearSel?.value || '';

        const d = Number(dateVal);
        const y = Number(yearVal);

        if (!isNaN(d) && !isNaN(y) && monthVal) {
          const monthMap = { jan:1, feb:2, mar:3, apr:4, may:5, jun:6, jul:7, aug:8, sep:9, oct:10, nov:11, dec:12 };
          let mIndex = Number(monthVal);
          if (isNaN(mIndex)) {
            const mm = String(monthVal).trim().slice(0,3).toLowerCase();
            mIndex = monthMap[mm] || NaN;
          }
          if (!isNaN(mIndex)) {
            const isoDate = new Date(y, mIndex - 1, d, 9, 0, 0);
            if (!isNaN(isoDate.getTime())) scheduledAt = isoDate.toISOString();
          }
        }
      } catch (e) {}

      const notes = document.getElementById('notes')?.value?.trim() || '';
      const recipient = document.getElementById('recipient')?.value?.trim() || '';

      // compute totals again (source of truth: cart array)
      let totalPrice = 0;
      cart.forEach(it => {
        totalPrice += Number(
          it.subtotal ||
          (Number(it.unitPrice || it.price || 0) * Number(it.qty || 0)) ||
          0
        );
      });

      const selectedDelivery = document.querySelector('.delivery-item.active')?.dataset.method || 'regular';
      let baseOngkir = 15000;
      switch (selectedDelivery) {
        case 'regular': baseOngkir = 15000; break;
        case 'nextday': baseOngkir = 20000; break;
        case 'sameday': baseOngkir = 30000; break;
        case 'instant': baseOngkir = 50000; break;
        case 'self': baseOngkir = 5000; break;
        default: baseOngkir = 15000; break;
      }
      const totalItems = cart.reduce((s, it) => s + (Number(it.qty || 0)), 0);
      const kelipatan = Math.max(1, Math.ceil(totalItems / 5));
      const shippingFee = baseOngkir * kelipatan;
      const grandTotal = Number(totalPrice) + Number(shippingFee);

      // ---- cek apakah ini GIFT order (data dari gif.html) ----
      let giftConfig = null;
      try {
        giftConfig = JSON.parse(localStorage.getItem('giftConfig_v1') || 'null');
      } catch (e) {
        giftConfig = null;
      }
      const isGift = !!(giftConfig && giftConfig.type === 'gift');

      // prepare order object
      const order = {
        id: genOrderId(),
        createdAt: Date.now(),
        status: 'scheduled',
        scheduledAt: scheduledAt,
        total: grandTotal,
        shippingFee: shippingFee,
        items: cart.map(it => ({
          id: it.id,
          title: it.title,
          qty: Number(it.qty || 1),
          unitPrice: Number(it.unitPrice || it.price || 0),
          subtotal: Number(
            it.subtotal ||
            (Number(it.unitPrice || it.price || 0) * Number(it.qty || 1))
          ),
          addons: it.addons || [],
          image: it.image || (it.images && it.images[0]) || ''
        })),

        meta: {
          notes: notes,
          recipient: recipient,
          deliveryMethod: selectedDelivery
        },
        paymentStatus: 'pending'
      };

      if (isGift) {
        order.isGift = true;
        order.gift = {
          message: giftConfig.message || '',
          fromName: giftConfig.fromName || '',
          revealMode: giftConfig.revealMode || 'reveal',
          theme: giftConfig.theme || null
        };
      }

      // ====== SIMPAN ORDER KE FIRESTORE (untuk admin) ======
      const uid   = localStorage.getItem("maziUID")   || null;
      const email = localStorage.getItem("maziEmail") || "";
      const name  = localStorage.getItem("maziName")  || "";

      try {
        const firestoreOrder = {
          userId: uid,
          userEmail: email,
          userName: name,
          ...order,
          createdAt: serverTimestamp()
        };

        const docRef = await addDoc(collection(db, "orders"), firestoreOrder);
        console.log("Order tersimpan di Firestore dengan id:", docRef.id);

        order.firestoreId = docRef.id;

      } catch (err) {
        console.error("Gagal menyimpan order ke Firestore:", err);
        try {
          const queued = Object.assign({}, order, {
            userId: uid,
            userEmail: email,
            userName: name,
            queuedAt: Date.now()
          });
          enqueueLocalOrder(queued);
          alert("Peringatan: koneksi ke server bermasalah. Pesanan disimpan sementara dan akan dikirim ke server saat koneksi pulih.");
        } catch (e) {
          console.error('Failed to enqueue order after firestore write error', e);
        }
      }

      // save orders (most recent first)
      const orders = loadOrders();
      orders.unshift(order);
      saveOrders(orders);

      // clear cart & gift config
      try { localStorage.removeItem('cart'); } catch (e) { /* ignore */ }
      try { localStorage.removeItem('giftConfig_v1'); } catch (e) { /* ignore */ }

      // WhatsApp ke admin + splash
      try {
        const waNumber = '628118281416';
        let waText = '';

        if (isGift) {
          const tgl = scheduledAt
            ? new Date(scheduledAt).toLocaleString('id-ID')
            : '(tanpa jadwal)';
          waText =
            `Halo mimin Mazi, ini pesanan GIFT terjadwal dengan ID ${order.id}. ` +
            `Mohon dibantu proses untuk jadwal ${tgl}.`;
        } else {
          waText =
            `Halo mimin Mazi, tolong proses pesanan terjadwal saya dengan ID ${order.id}.`;
        }

        const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(waText)}`;

        const overlay = document.getElementById('ddno-overlay');
        const logo = document.getElementById('ddno-logo');

        if (overlay) {
          overlay.classList.add('show');
        }
        if (logo) {
          logo.classList.remove('show');
          setTimeout(() => {
            logo.classList.add('show');
          }, 50);
        }

        setTimeout(() => {
          try {
            window.open(waUrl, '_blank');
          } catch (err) {
            console.warn('Failed to open WhatsApp', err);
          }

          window.location.href =
            './order.html?order=' + encodeURIComponent(order.id);
        }, 1500);
      } catch (e) {
        console.warn('Failed to prepare WhatsApp redirect', e);
        window.location.href =
          './order.html?order=' + encodeURIComponent(order.id);
      }
    });
  }

  // ---- initial render ----
  // register auth listener to flush queue when user logs in
  try {
    if (typeof onAuthStateChanged === 'function') {
      onAuthStateChanged(auth, (user) => {
        if (user) {
          console.log('onAuthStateChanged: user logged in — attempting to flush order queue');
          if (typeof flushOrderQueue === 'function') {
            flushOrderQueue().catch(err => console.warn('flushOrderQueue error', err));
          } else {
            console.log('flushOrderQueue not defined on this page (will flush when available)');
          }
        } else {
          console.log('onAuthStateChanged: no user — not flushing order queue');
        }
      });
    } else {
      console.warn('onAuthStateChanged is not a function — did you import it?');
    }
  } catch (e) {
    console.warn('Failed to register auth listener', e);
  }

  populateScheduleSelectors({ yearsAhead: 5 });
  renderProductsFromCart();
  calcSubtotal();
});
