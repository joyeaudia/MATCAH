// singin.js — versi lokal, tanpa Firebase (DEMO ONLY)

// 🔐 akun admin fix (hardcoded)
const ADMIN_EMAIL = "byverent@gmail.com";
const ADMIN_PASSWORD = "5Bisnis2021";

function loadUsers() {
  try {
    return JSON.parse(localStorage.getItem("maziUsers") || "[]");
  } catch {
    return [];
  }
}

// toggle show/hide password
document.querySelectorAll(".toggle").forEach((icon) => {
  icon.addEventListener("click", () => {
    const input = icon.previousElementSibling;
    if (!input) return;
    input.type = input.type === "password" ? "text" : "password";
    icon.textContent = input.type === "password" ? "👁️" : "🙈";
  });
});

const signInBtn = document.getElementById("signInBtn");

if (signInBtn) {
  signInBtn.addEventListener("click", () => {
    const emailEl = document.getElementById("email");
    const passwordEl = document.getElementById("password");

    const userEmailValue = (emailEl?.value || "").trim();
    const userPasswordValue = passwordEl?.value || "";

    if (!userEmailValue || !userPasswordValue) {
      alert("Isi email dan password dulu ya 🙂");
      return;
    }

    // 💼 1) CEK AKUN ADMIN TETAP DULU (hardcoded)
    if (
      userEmailValue.toLowerCase() === ADMIN_EMAIL.toLowerCase() &&
      userPasswordValue === ADMIN_PASSWORD
    ) {
      const name = "Admin Verent";

      // simpan session admin
      localStorage.setItem("maziRole", "admin");
      localStorage.setItem("maziEmail", ADMIN_EMAIL);
      localStorage.setItem("maziName", name);
      localStorage.setItem("maziPhone", "");
      localStorage.setItem("maziUID", "admin-fixed"); // UID khusus admin

      // siapkan profile untuk prl.html (kalau dibutuhkan)
      const profile = {
        firstName: "Admin",
        lastName: "Verent",
        email: ADMIN_EMAIL,
        phone: "",
        memberSince: new Date().getFullYear(),
      };
      localStorage.setItem("profile", JSON.stringify(profile));

      // langsung ke halaman admin
      window.location.href = "frsadm.html";
      return; // ⬅ penting: jangan lanjut ke cek user biasa
    }

    // 👤 2) BUKAN ADMIN FIX → cek di localStorage users
    const users = loadUsers();
    const found = users.find(
      (u) => u.email.toLowerCase() === userEmailValue.toLowerCase()
    );

    if (!found) {
      alert("Email belum terdaftar. Silakan Sign Up dulu ya 🙂");
      return;
    }
    if (found.password !== userPasswordValue) {
      alert("Password salah. Coba lagi ya 😊");
      return;
    }

    // tentukan role
    let role = found.role || "user";
    if (
      !found.role &&
      userEmailValue.toLowerCase() === ADMIN_EMAIL.toLowerCase()
    ) {
      role = "admin";
    }

    const name = found.name || "";
    const phone = found.phone || "";

    // simpan session user
    localStorage.setItem("maziRole", role);
    localStorage.setItem("maziEmail", userEmailValue);
    localStorage.setItem("maziName", name);
    localStorage.setItem("maziPhone", phone);
    localStorage.setItem("maziUID", found.id); // 🔑 ini yang jadi kunci data per user

    // restore draft checkout kalau ada
    try {
      if (typeof window.flushOrderQueue === "function") {
        window.flushOrderQueue().catch((e) =>
          console.warn("flush after sign-in failed", e)
        );
      }
    } catch (e) {
      console.warn("flushOrderQueue throw", e);
    }

    const sp = new URLSearchParams(window.location.search);
    const from = sp.get("from");
    if (from === "bag" || from === "checkout") {
      try {
        const draft = JSON.parse(
          localStorage.getItem("checkoutDraft_cart") || "null"
        );
        if (draft) {
          localStorage.setItem("cart", JSON.stringify(draft));
          localStorage.removeItem("checkoutDraft_cart");
        }
      } catch (e) {
        console.warn("failed restore draft", e);
      }

      window.location.href = from === "bag" ? "bagfr.html" : "cekout.html";
      return;
    }

    // siapkan profile untuk prl.html
    const parts = (name || "").split(/\s+/);
    const firstName = parts[0] || "";
    const lastName = parts.slice(1).join(" ");

    const existingRaw = localStorage.getItem("profile");
    let profile = null;
    try {
      profile = JSON.parse(existingRaw || "null");
    } catch {
      profile = null;
    }

    if (
      !profile ||
      (profile.email || "").toLowerCase() !== userEmailValue.toLowerCase()
    ) {
      profile = {
        firstName,
        lastName,
        email: userEmailValue,
        phone,
        memberSince: found.memberSince || new Date().getFullYear(),
      };
    } else {
      profile = {
        ...profile,
        firstName,
        lastName,
        phone: phone || profile.phone,
      };
    }

    localStorage.setItem("profile", JSON.stringify(profile));

    // redirect sesuai role
    if (role === "admin") {
      window.location.href = "frsadm.html";
    } else {
      window.location.href = "Home.html";
    }
  });
}
